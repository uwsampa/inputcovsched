/*
 * Copyright (C) 2003-2006 Manuel Novoa III <mjn3@uclibc.org>
 *
 * Licensed under the LGPL v2.1, see the file COPYING.LIB in this tarball.
 */

#define L___C_ctype_tolower
#include "ctype.c"
